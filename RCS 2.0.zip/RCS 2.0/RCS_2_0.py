import maya.cmds as cmds
import random
import math

class RykovsControlShaker:
    def __init__(self):
        self.window_name = "rykovsControlShakerWindow"

        if cmds.window(self.window_name, exists=True):
            cmds.deleteUI(self.window_name, window=True)

        self.window = cmds.window(self.window_name, title="Rykov's Control Shaker", widthHeight=(400, 500), sizeable=False)
        self.main_layout = cmds.columnLayout(adjustableColumn=True, columnAlign="center")

        self.build_interface()
        cmds.scriptJob(event=["playbackRangeChanged", self.sync_with_timeline], parent=self.window)
        cmds.showWindow(self.window)

    def build_interface(self):
        cmds.text(label="Rykov's Control Shaker", font="boldLabelFont", height=10, parent=self.main_layout)
        cmds.separator(height=10, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Parameters", collapsable=False, parent=self.main_layout, marginWidth=5, marginHeight=5)
        cmds.columnLayout(adjustableColumn=True, columnAlign="center")
        self.translation_slider = cmds.floatSliderGrp(label="Translation:", field=True, minValue=0.001, maxValue=100, value=0.01, columnAlign=(1, "left"), columnWidth=(1, 100))
        self.rotation_slider = cmds.floatSliderGrp(label="Rotation:", field=True, minValue=0, maxValue=360, value=0.5, columnAlign=(1, "left"), columnWidth=(1, 100))
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Axes", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.rowLayout(numberOfColumns=2, adjustableColumn=1, columnWidth2=(150, 150), columnAttach=[(1, "both", 5), (2, "both", 5)])
        cmds.columnLayout(adjustableColumn=True, columnAlign="left")
        self.x_axis_checkbox = cmds.checkBox(label="X", value=True)
        self.y_axis_checkbox = cmds.checkBox(label="Y", value=True)
        self.z_axis_checkbox = cmds.checkBox(label="Z", value=True)
        cmds.setParent("..")
        cmds.columnLayout(adjustableColumn=True, columnAlign="left")
        self.neg_x_axis_checkbox = cmds.checkBox(label="-X", value=False)
        self.neg_y_axis_checkbox = cmds.checkBox(label="-Y", value=False)
        self.neg_z_axis_checkbox = cmds.checkBox(label="-Z", value=False)
        cmds.setParent("..")
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Modes", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.rowLayout(numberOfColumns=2, columnWidth2=(50, 300), adjustableColumn=2)
        cmds.text(label="Mode:")
        self.shake_mode_radio = cmds.radioButtonGrp(labelArray3=["Random", "Sinusoidal", "Variable Amplitude"], numberOfRadioButtons=3, select=1, columnAlign4=("center", "center", "center", "center"), columnWidth4=(1, 100, 100, 100))
        cmds.setParent("..")
        cmds.separator(height=10, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Bake Options", collapsable=False, parent=self.main_layout, marginWidth=5, marginHeight=5)
        self.bake_layer_checkbox = cmds.checkBox(label="Bake Animation on New Layer", value=True)
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Number of Frames", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.columnLayout(adjustableColumn=True, columnAlign="center")
        self.start_frame_field = cmds.intField(value=cmds.playbackOptions(q=True, min=True), annotation="Start Frame:")
        self.end_frame_field = cmds.intField(value=cmds.playbackOptions(q=True, max=True), annotation="End Frame:")
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.button(label="Shake", command=self.run_animation, backgroundColor=(0, 0.5, 0), parent=self.main_layout)

        cmds.separator(height=15, style="none", parent=self.main_layout)
        cmds.rowLayout(numberOfColumns=2, adjustableColumn=2, columnWidth2=(50, 300), columnAlign=(1, "right"), parent=self.main_layout)
        cmds.text(label="Email:", align="right")
        cmds.textField(text="padavanr@gmail.com", editable=False)

    def sync_with_timeline(self):
        start_frame = cmds.playbackOptions(q=True, min=True)
        end_frame = cmds.playbackOptions(q=True, max=True)
        cmds.intField(self.start_frame_field, edit=True, value=start_frame)
        cmds.intField(self.end_frame_field, edit=True, value=end_frame)

    def run_animation(self, *args):
        cmds.warning("Shake functionality is not implemented yet!")

rykov_shaker = RykovsControlShaker()
