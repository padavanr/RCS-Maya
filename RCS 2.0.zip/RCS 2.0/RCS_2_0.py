import maya.cmds as cmds
import random
import math

class RykovsControlShaker:
    def __init__(self):
        self.window_name = "rykovsControlShakerWindow"

        if cmds.window(self.window_name, exists=True):
            cmds.deleteUI(self.window_name, window=True)

        self.window = cmds.window(self.window_name, title="Rykov's Control Shaker", widthHeight=(400, 500), sizeable=False)
        self.main_layout = cmds.columnLayout(adjustableColumn=True, columnAlign="center")

        self.build_interface()
        cmds.scriptJob(event=["playbackRangeChanged", self.sync_with_timeline], parent=self.window)
        cmds.showWindow(self.window)

    def build_interface(self):
        cmds.text(label="Rykov's Control Shaker", font="boldLabelFont", height=10, parent=self.main_layout)
        cmds.separator(height=10, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Parameters", collapsable=False, parent=self.main_layout, marginWidth=5, marginHeight=5)
        cmds.columnLayout(adjustableColumn=True, columnAlign="center")
        self.translation_slider = cmds.floatSliderGrp(label="Translation:", field=True, minValue=0.001, maxValue=100, value=0.01, columnAlign=(1, "left"), columnWidth=(1, 100))
        self.rotation_slider = cmds.floatSliderGrp(label="Rotation:", field=True, minValue=0, maxValue=360, value=0.5, columnAlign=(1, "left"), columnWidth=(1, 100))
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Axes", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.rowLayout(numberOfColumns=2, adjustableColumn=1, columnWidth2=(150, 150), columnAttach=[(1, "both", 5), (2, "both", 5)])
        cmds.columnLayout(adjustableColumn=True, columnAlign="left")
        self.x_axis_checkbox = cmds.checkBox(label="X", value=True)
        self.y_axis_checkbox = cmds.checkBox(label="Y", value=True)
        self.z_axis_checkbox = cmds.checkBox(label="Z", value=True)
        cmds.setParent("..")
        cmds.columnLayout(adjustableColumn=True, columnAlign="left")
        self.neg_x_axis_checkbox = cmds.checkBox(label="-X", value=False)
        self.neg_y_axis_checkbox = cmds.checkBox(label="-Y", value=False)
        self.neg_z_axis_checkbox = cmds.checkBox(label="-Z", value=False)
        cmds.setParent("..")
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Shake Modes", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.rowLayout(numberOfColumns=2, columnWidth2=(50, 300), adjustableColumn=2)
        cmds.text(label="Mode:")
        self.shake_mode_radio = cmds.radioButtonGrp(labelArray3=["Random", "Sinusoidal", "Variable Amplitude"], numberOfRadioButtons=3, select=1, columnAlign4=("center", "center", "center", "center"), columnWidth4=(1, 100, 100, 100))
        cmds.setParent("..")
        cmds.separator(height=10, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Bake Options", collapsable=False, parent=self.main_layout, marginWidth=5, marginHeight=5)
        self.bake_layer_checkbox = cmds.checkBox(label="Bake Animation on New Layer", value=True)
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.frameLayout(label="Number of Frames", collapsable=False, parent=self.main_layout, marginWidth=10, marginHeight=10)
        cmds.columnLayout(adjustableColumn=True, columnAlign="center")
        self.start_frame_field = cmds.intField(value=cmds.playbackOptions(q=True, min=True), annotation="Start Frame:")
        self.end_frame_field = cmds.intField(value=cmds.playbackOptions(q=True, max=True), annotation="End Frame:")
        cmds.setParent("..")
        cmds.separator(height=5, style="in", parent=self.main_layout)

        cmds.button(label="Shake", command=self.run_animation, backgroundColor=(0, 0.5, 0), parent=self.main_layout)

        cmds.separator(height=15, style="none", parent=self.main_layout)
        cmds.rowLayout(numberOfColumns=2, adjustableColumn=2, columnWidth2=(50, 300), columnAlign=(1, "right"), parent=self.main_layout)
        cmds.text(label="Email:", align="right")
        cmds.textField(text="padavanr@gmail.com", editable=False)

    def sync_with_timeline(self):
        start_frame = cmds.playbackOptions(q=True, min=True)
        end_frame = cmds.playbackOptions(q=True, max=True)
        cmds.intField(self.start_frame_field, edit=True, value=start_frame)
        cmds.intField(self.end_frame_field, edit=True, value=end_frame)

    def run_animation(self, *args):
        selected_objects = cmds.ls(selection=True)
        if not selected_objects:
            cmds.warning("Select at least one object to apply the shake animation.")
            return

        translation_amount = cmds.floatSliderGrp(self.translation_slider, query=True, value=True)
        rotation_amount = cmds.floatSliderGrp(self.rotation_slider, query=True, value=True)
        mode_index = cmds.radioButtonGrp(self.shake_mode_radio, query=True, select=True)
        mode = ["Random", "Sinusoidal", "Variable Amplitude"][mode_index - 1]
        bake_layer = cmds.checkBox(self.bake_layer_checkbox, query=True, value=True)

        axes = {
            "positive": [],
            "negative": []
        }
        
        if cmds.checkBox(self.x_axis_checkbox, query=True, value=True):
            axes["positive"].append("X")
        if cmds.checkBox(self.y_axis_checkbox, query=True, value=True):
            axes["positive"].append("Y")
        if cmds.checkBox(self.z_axis_checkbox, query=True, value=True):
            axes["positive"].append("Z")
        if cmds.checkBox(self.neg_x_axis_checkbox, query=True, value=True):
            axes["negative"].append("X")
        if cmds.checkBox(self.neg_y_axis_checkbox, query=True, value=True):
            axes["negative"].append("Y")
        if cmds.checkBox(self.neg_z_axis_checkbox, query=True, value=True):
            axes["negative"].append("Z")

        start_frame = cmds.intField(self.start_frame_field, query=True, value=True)
        end_frame = cmds.intField(self.end_frame_field, query=True, value=True)

        for obj in selected_objects:
            if bake_layer:
                layer_name = "{}_shake".format(obj)
                if not cmds.animLayer(layer_name, query=True, exists=True):
                    cmds.animLayer(layer_name, addSelectedObjects=True)

            for frame in range(start_frame, end_frame + 1):
                cmds.currentTime(frame, edit=True)
                self.apply_shake(obj, frame, mode, translation_amount, rotation_amount, axes)
                if bake_layer:
                    cmds.setKeyframe(obj, attribute=["translateX", "translateY", "translateZ", "rotateX", "rotateY", "rotateZ"], animLayer=layer_name)
                else:
                    cmds.setKeyframe(obj, attribute=["translateX", "translateY", "translateZ", "rotateX", "rotateY", "rotateZ"])

        cmds.inViewMessage(amg="Shake animation completed!", pos="topCenter", fade=True)

    def apply_shake(self, object_name, frame, mode, translation_amount, rotation_amount, axes):
        current_translation = cmds.xform(object_name, query=True, translation=True, worldSpace=True)
        current_rotation = cmds.xform(object_name, query=True, rotation=True, worldSpace=True)

        random_translation = current_translation[:]
        random_rotation = current_rotation[:]

        for i, axis in enumerate(["X", "Y", "Z"]):
            if mode == "Random":
                if axis in axes["positive"]:
                    random_translation[i] += random.uniform(0, translation_amount)
                if axis in axes["negative"]:
                    random_translation[i] += random.uniform(-translation_amount, 0)
                random_rotation[i] += random.uniform(-rotation_amount, rotation_amount)

            elif mode == "Sinusoidal":
                value = math.sin(frame * 0.1) * translation_amount
                if axis in axes["positive"]:
                    random_translation[i] += value
                elif axis in axes["negative"]:
                    random_translation[i] -= value
                random_rotation[i] += value * (rotation_amount / (translation_amount or 0.001))

            elif mode == "Variable Amplitude":
                factor = 1 - abs((frame % 50) - 25) / 25.0
                if axis in axes["positive"]:
                    random_translation[i] += factor * random.uniform(0, translation_amount)
                if axis in axes["negative"]:
                    random_translation[i] += factor * random.uniform(-translation_amount, 0)
                random_rotation[i] += factor * random.uniform(-rotation_amount, rotation_amount)

        cmds.move(random_translation[0], random_translation[1], random_translation[2], object_name, absolute=True)
        cmds.rotate(random_rotation[0], random_rotation[1], random_rotation[2], object_name, absolute=True)

rykov_shaker = RykovsControlShaker()
