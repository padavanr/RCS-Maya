import maya.cmds as cmds
import random

class RykovsControlShaker:
    def __init__(self):
        self.window_name = "rykovsControlShakerWindow"

        if cmds.window(self.window_name, exists=True):
            cmds.deleteUI(self.window_name, window=True)

        self.window = cmds.window(self.window_name, title="Rykov's Control Shaker", widthHeight=(400, 250))
        self.layout = cmds.columnLayout(adjustableColumn=True, columnAlign="center", rowSpacing=10)

        cmds.frameLayout(label="Shake Parameters", collapsable=True, collapse=False, parent=self.layout, backgroundColor=(0.2, 0.5, 0.2))
        self.translation_slider = cmds.floatSliderGrp(value=0.01, minValue=0.001, maxValue=10, step=0.01, precision=3,
                                                      label="Trans:",
                                                      field=True, width=350, columnWidth=(1, 75),
                                                      annotation="Translation Shake:")

        self.rotation_slider = cmds.floatSliderGrp(value=0.5, minValue=0, maxValue=180, step=0.1, precision=1,
                                                   label="Rot:",
                                                   field=True, width=350, columnWidth=(1, 75),
                                                   annotation="Rotation Shake:")

        cmds.rowLayout(numberOfColumns=3, columnWidth3=(80, 80, 80))
        self.x_axis_checkbox = cmds.checkBox(label="X", value=True)
        self.y_axis_checkbox = cmds.checkBox(label="Y", value=True)
        self.z_axis_checkbox = cmds.checkBox(label="Z", value=True)
        cmds.setParent(self.layout)

        cmds.frameLayout(label="Impuls Parameters", collapsable=True, collapse=False, parent=self.layout, backgroundColor=(0.5, 0.2, 0.2))
        self.min_translation_slider = cmds.floatSliderGrp(value=0.001, minValue=0, maxValue=0.1, step=0.001, precision=4,
                                                          label="Min Trans:",
                                                          field=True, width=350, columnWidth=(1, 75),
                                                          annotation="Min Translation:")

        self.min_rotation_slider = cmds.floatSliderGrp(value=0.1, minValue=0, maxValue=10, step=0.1, precision=1,
                                                       label="Min Rot:",
                                                       field=True, width=350, columnWidth=(1, 75),
                                                       annotation="Min Rotation:")

        cmds.frameLayout(label="Number of Frames", collapsable=True, collapse=False, parent=self.layout, backgroundColor=(0.2, 0.5, 0.5))
        self.start_frame_field = cmds.intField(value=1, minValue=1, annotation="Start Frame:")
        self.end_frame_field = cmds.intField(value=60, minValue=1, annotation="End Frame:")

        cmds.button(label="Run Animation", command=self.run_animation, backgroundColor=(0.4, 0.4, 0.4))
        cmds.showWindow(self.window)

    def apply_random_noise(self, object_name, translation_amount=0.01, rotation_amount=0.5):
        min_translation = cmds.floatSliderGrp(self.min_translation_slider, query=True, value=True)
        min_rotation = cmds.floatSliderGrp(self.min_rotation_slider, query=True, value=True)

        translation_amount = max(translation_amount, min_translation)
        rotation_amount = max(rotation_amount, min_rotation)

        selected_axes = self.get_selected_axes()
        for axis in selected_axes:
            random_translation = [0, 0, 0]
            random_rotation = [0, 0, 0]

            if 'X' in axis:
                random_translation[0] = random.uniform(-translation_amount, translation_amount)
                random_rotation[0] = random.uniform(-rotation_amount, rotation_amount)
            elif 'Y' in axis:
                random_translation[1] = random.uniform(-translation_amount, translation_amount)
                random_rotation[1] = random.uniform(-rotation_amount, rotation_amount)
            elif 'Z' in axis:
                random_translation[2] = random.uniform(-translation_amount, translation_amount)
                random_rotation[2] = random.uniform(-rotation_amount, rotation_amount)

            cmds.move(random_translation[0], random_translation[1], random_translation[2], object_name, relative=True)
            cmds.rotate(random_rotation[0], random_rotation[1], random_rotation[2], object_name, relative=True)

    def get_selected_axes(self):
        selected_axes = []
        if cmds.checkBox(self.x_axis_checkbox, query=True, value=True):
            selected_axes.append('X')
        if cmds.checkBox(self.y_axis_checkbox, query=True, value=True):
            selected_axes.append('Y')
        if cmds.checkBox(self.z_axis_checkbox, query=True, value=True):
            selected_axes.append('Z')
        return selected_axes

    def shake_animation(self, object_name, start_frame, end_frame, translation_amount=0.01, rotation_amount=0.5):
        for frame in range(start_frame, end_frame + 1):
            cmds.currentTime(frame, edit=True)
            self.apply_random_noise(object_name, translation_amount, rotation_amount)
            cmds.setKeyframe(object_name, attribute='translateX')
            cmds.setKeyframe(object_name, attribute='translateY')
            cmds.setKeyframe(object_name, attribute='translateZ')
            cmds.setKeyframe(object_name, attribute='rotateX')
            cmds.setKeyframe(object_name, attribute='rotateY')
            cmds.setKeyframe(object_name, attribute='rotateZ')

        print("Shake animation for {} completed.".format(object_name))

    def run_animation(self, *args):
        selected_objects = cmds.ls(selection=True, dag=True, long=True)

        if not selected_objects:
            cmds.warning("Select an object in the scene.")
            return

        object_name = selected_objects[0]
        translation_amount = cmds.floatSliderGrp(self.translation_slider, query=True, value=True)
        rotation_amount = cmds.floatSliderGrp(self.rotation_slider, query=True, value=True)
        start_frame = cmds.intField(self.start_frame_field, query=True, value=True)
        end_frame = cmds.intField(self.end_frame_field, query=True, value=True)

        self.shake_animation(object_name, start_frame, end_frame, translation_amount, rotation_amount)

rykov_shaker = RykovsControlShaker()